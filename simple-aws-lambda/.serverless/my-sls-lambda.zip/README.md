# Simple AWS Lambda #

* npm install
* serverless package
* serverless deploy
* serverless invoke local --function=helloworld --log
* serverless invoke --function helloworld